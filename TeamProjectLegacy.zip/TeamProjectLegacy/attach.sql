drop table attach

//////////////////////////////////////

CREATE TABLE attach(
	filename VARCHAR2(300) NOT NULL,
	bno NUMBER NOT NULL,
	regdate DATE DEFAULT SYSDATE
)


